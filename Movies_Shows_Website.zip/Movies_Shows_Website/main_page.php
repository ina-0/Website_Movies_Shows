<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MovieMania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
    <style>
        .modal-content
        {
            width: 600px;
            max-height: 500px !important;  /* Adjust this value as needed */
            background-color: rgb(220, 220, 187);
            overflow-y: auto;   /* Add this to enable scrolling if content exceeds max-height */
        }
    </style>
  </head>
<body>
        <!--Header-->

    <!--header with movie name and background posters -->
    <div id="header">
        <div id="background_poster" class="transition_poster">

            <!--the container of the name of the website-->
            <div id="name_box">
                <div id="movie_name">MovieMania</div>
            </div>

            <!--the container with all the posters that are going to be shown-->
            <div class="poster_container">
                <img src="images/movies/all_the_bright_places.jpeg" alt="Show 1">
                <img src="images/movies/arrietty.png" alt="Show 2">
                <img src="images/movies/avengers.jpg" alt="Show 3">
                <img src="images/movies/avengers_endgame.jpg" alt="Show 4">
                <img src="images/movies/baby_driver.jpg" alt="Show 5">
                <img src="images/movies/barbie.jfif" alt="Show 6">
                <img src="images/movies/barbie_animated.jpg" alt="Show 7">
                <img src="images/movies/blade_runner_2049.png" alt="Show 8">
                <img src="images/movies/call_me_by_your_name.png" alt="Show 9">
                <img src="images/movies/captain_america.jpg" alt="Show 10">
                <img src="images/movies/death_on_the_nile.jfif" alt="Show 11">
                <img src="images/movies/divergent.jpg" alt="Show 12">
                <img src="images/movies/everything_everywhere_all_at_once.jfif" alt="Show 13">
                <img src="images/movies/exorcist.jpg" alt="Show 14">
                <img src="images/movies/fnaf.jfif" alt="Show 15">
                <img src="images/movies/ghostbusters.png" alt="Show 16">
                <img src="images/movies/gone_girl.jpg" alt="Show 17">
                <img src="images/movies/harry_potter1.jpg" alt="Show 18">
                <img src="images/movies/harry_potter2.jpg" alt="Show 19">
                <img src="images/movies/how_to_train_your_dragon.jpg" alt="Show 20">
                <img src="images/movies/howls_moving_castle.jpg" alt="Show 21">
                <img src="images/movies/hunger_games1.jpg" alt="Show 22">
                <img src="images/movies/hunger_games2.jpg" alt="Show 23">
                <img src="images/movies/hunger_games3.jpg" alt="Show 24">
                <img src="images/movies/hunger_games4.jpg" alt="Show 25">
                <img src="images/movies/insidious1.jpg" alt="Show 26">
                <img src="images/movies/insidious2.jpg" alt="Show 27">
                <img src="images/movies/insidious3.png" alt="Show 28">
                <img src="images/movies/insidious4.jpg" alt="Show 29">
                <img src="images/movies/jumanji1.png" alt="Show 31">
                <img src="images/movies/jumanji2.jpg" alt="Show 32">
                <img src="images/movies/jumanji_og.jpg" alt="Show 33">
                <img src="images/movies/jurassic_park1.jpg" alt="Show 34">
                <img src="images/movies/jurassic_park2.jpg" alt="Show 35">
                <img src="images/movies/jurassic_park3.jpg" alt="Show 36">
                <img src="images/movies/jurassic_world1.jpg" alt="Show 37">
                <img src="images/movies/jurassic_world2.png" alt="Show 38">
                <img src="images/movies/kikis_delivery_service.jpg" alt="Show 39">
                <img src="images/movies/little_mermaid.png" alt="Show 40">
                <img src="images/movies/mean_girls.jfif" alt="Show 41">
                <img src="images/movies/men_in_black1.jpg" alt="Show 42">
                <img src="images/movies/men_in_black2.jpg" alt="Show 43">
                <img src="images/movies/mission_impossible2.jpg" alt="Show 44">
                <img src="images/movies/mission_impossible3.jpg" alt="Show 45">
                <img src="images/movies/mission_impossible6.jpg" alt="Show 46">
                <img src="images/movies/murder_mystery.png" alt="Show 47">
                <img src="images/movies/murder_mystery2.jfif" alt="Show 48">
                <img src="images/movies/my_neighbour_totoro.jpg" alt="Show 49">
                <img src="images/movies/nightmare_on_elm_street1.jpg" alt="Show 50">
                <img src="images/movies/nightmare_on_elm_street2.jpg" alt="Show 51">
                <img src="images/movies/oppenheimer.jfif" alt="Show 52">
                <img src="images/movies/pinocchio.jpg" alt="Show 53">
                <img src="images/movies/purple_hearts.png" alt="Show 54">
                <img src="images/movies/shrek.jpg" alt="Show 55">
                <img src="images/movies/shutter_island.jpg" alt="Show 56">
                <img src="images/movies/spiderman_new.jpg" alt="Show 57">
                <img src="images/movies/spiderman_og.jpg" alt="Show 58">
                <img src="images/movies/spirited_away.png" alt="Show 59">
                <img src="images/movies/split.jpg" alt="Show 60">
                <img src="images/movies/star_wars1.jpg" alt="Show 61">
                <img src="images/movies/star_wars3.jpg" alt="Show 62">
                <img src="images/movies/star_wars4.jpg" alt="Show 63">
                <img src="images/movies/star_wars6.jpg" alt="Show 64">
                <img src="images/movies/star_wars7.jpg" alt="Show 65">
                <img src="images/movies/the_conjuring1.jpg" alt="Show 66">
                <img src="images/movies/the_conjuring2.jpg" alt="Show 67">
                <img src="images/movies/the_fault_in_our_stars.png" alt="Show 68">
                <img src="images/movies/the_nun2.jfif" alt="Show 69">
                <img src="images/movies/thor.jpg" alt="Show 70">
                <img src="images/movies/titanic.jfif" alt="Show 71">
                <img src="images/movies/to_all_the_boys_ive_loved_before1.jpg" alt="Show 72">
                <img src="images/movies/to_all_the_boys_ive_loved_before2.jpg" alt="Show 73">
                <img src="images/movies/top_gun.jpg" alt="Show 74">
                <img src="images/movies/toy_story.jpg" alt="Show 75">
                <img src="images/movies/toy_story2.jpg" alt="Show 76">
                <img src="images/movies/uncharted.jfif" alt="Show 77">
                <img src="images/movies/world_war_z.jpg" alt="Show 78">
                <img src="images/movies/zodiac.jpg" alt="Show 79">
                <img src="images/series/alice_in_borderland.jfif" alt="Show 80">
                <img src="images/series/alienist.jpg" alt="Show 81">
                <img src="images/series/attack_on_titan.jfif" alt="Show 82">
                <img src="images/series/black_mirror.jpg" alt="Show 83">
                <img src="images/series/breaking_bad.jfif" alt="Show 84">
                <img src="images/series/bridgerton.jfif" alt="Show 85">
                <img src="images/series/dahmer.jpg" alt="Show 86">
                <img src="images/series/derry_girls.jpg" alt="Show 87">
                <img src="images/series/friends.jfif" alt="Show 88">
                <img src="images/series/haunting_of_hill_house.jpg" alt="Show 89">
                <img src="images/series/heartstopper.jpg" alt="Show 90">
                <img src="images/series/lucifer.jfif" alt="Show 91">
                <img src="images/series/midnight_club.jfif" alt="Show 92">
                <img src="images/series/one_piece.jfif" alt="Show 93">
                <img src="images/series/outer_banks.jfif" alt="Show 94">
                <img src="images/series/queens_gambit.jpg" alt="Show 95">
                <img src="images/series/riverdale.jpg" alt="Show 96">
                <img src="images/series/sabrina.jpg" alt="Show 97">
                <img src="images/series/squid_game.jpg" alt="Show 98">
                <img src="images/series/stranger_things.jfif" alt="Show 99">
                <img src="images/series/the_empress.jpg" alt="Show 100">
                <img src="images/series/the_society.jpg" alt="Show 101">
                <img src="images/series/the_walking_dead.jfif" alt="Show 102">
                <img src="images/series/wednesday.jpg" alt="Show 103">
                <img src="images/series/you.jpg" alt="Show 104">

                <!--the poster are going to be shown again for looping-->
                <img src="images/movies/all_the_bright_places.jpeg" alt="Show 1">
                <img src="images/movies/arrietty.png" alt="Show 2">
                <img src="images/movies/avengers.jpg" alt="Show 3">
                <img src="images/movies/avengers_endgame.jpg" alt="Show 4">
                <img src="images/movies/baby_driver.jpg" alt="Show 5">
                <img src="images/movies/barbie.jfif" alt="Show 6">
                <img src="images/movies/barbie_animated.jpg" alt="Show 7">
                <img src="images/movies/blade_runner_2049.png" alt="Show 8">
                <img src="images/movies/call_me_by_your_name.png" alt="Show 9">
                <img src="images/movies/captain_america.jpg" alt="Show 10">
                <img src="images/movies/death_on_the_nile.jfif" alt="Show 11">
                <img src="images/movies/divergent.jpg" alt="Show 12">
                <img src="images/movies/everything_everywhere_all_at_once.jfif" alt="Show 13">
                <img src="images/movies/exorcist.jpg" alt="Show 14">
                <img src="images/movies/fnaf.jfif" alt="Show 15">
                <img src="images/movies/ghostbusters.png" alt="Show 16">
                <img src="images/movies/gone_girl.jpg" alt="Show 17">
                <img src="images/movies/harry_potter1.jpg" alt="Show 18">
                <img src="images/movies/harry_potter2.jpg" alt="Show 19">
                <img src="images/movies/how_to_train_your_dragon.jpg" alt="Show 20">
                <img src="images/movies/howls_moving_castle.jpg" alt="Show 21">
                <img src="images/movies/hunger_games1.jpg" alt="Show 22">
                <img src="images/movies/hunger_games2.jpg" alt="Show 23">
                <img src="images/movies/hunger_games3.jpg" alt="Show 24">
                <img src="images/movies/hunger_games4.jpg" alt="Show 25">
                <img src="images/movies/insidious1.jpg" alt="Show 26">
                <img src="images/movies/insidious2.jpg" alt="Show 27">
                <img src="images/movies/insidious3.png" alt="Show 28">
                <img src="images/movies/insidious4.jpg" alt="Show 29">
                <img src="images/movies/jumanji1.png" alt="Show 31">
                <img src="images/movies/jumanji2.jpg" alt="Show 32">
                <img src="images/movies/jumanji_og.jpg" alt="Show 33">
                <img src="images/movies/jurassic_park1.jpg" alt="Show 34">
                <img src="images/movies/jurassic_park2.jpg" alt="Show 35">
                <img src="images/movies/jurassic_park3.jpg" alt="Show 36">
                <img src="images/movies/jurassic_world1.jpg" alt="Show 37">
                <img src="images/movies/jurassic_world2.png" alt="Show 38">
                <img src="images/movies/kikis_delivery_service.jpg" alt="Show 39">
                <img src="images/movies/little_mermaid.png" alt="Show 40">
                <img src="images/movies/mean_girls.jfif" alt="Show 41">
                <img src="images/movies/men_in_black1.jpg" alt="Show 42">
                <img src="images/movies/men_in_black2.jpg" alt="Show 43">
                <img src="images/movies/mission_impossible2.jpg" alt="Show 44">
                <img src="images/movies/mission_impossible3.jpg" alt="Show 45">
                <img src="images/movies/mission_impossible6.jpg" alt="Show 46">
                <img src="images/movies/murder_mystery.png" alt="Show 47">
                <img src="images/movies/murder_mystery2.jfif" alt="Show 48">
                <img src="images/movies/my_neighbour_totoro.jpg" alt="Show 49">
                <img src="images/movies/nightmare_on_elm_street1.jpg" alt="Show 50">
                <img src="images/movies/nightmare_on_elm_street2.jpg" alt="Show 51">
                <img src="images/movies/oppenheimer.jfif" alt="Show 52">
                <img src="images/movies/pinocchio.jpg" alt="Show 53">
                <img src="images/movies/purple_hearts.png" alt="Show 54">
                <img src="images/movies/shrek.jpg" alt="Show 55">
                <img src="images/movies/shutter_island.jpg" alt="Show 56">
                <img src="images/movies/spiderman_new.jpg" alt="Show 57">
                <img src="images/movies/spiderman_og.jpg" alt="Show 58">
                <img src="images/movies/spirited_away.png" alt="Show 59">
                <img src="images/movies/split.jpg" alt="Show 60">
                <img src="images/movies/star_wars1.jpg" alt="Show 61">
                <img src="images/movies/star_wars3.jpg" alt="Show 62">
                <img src="images/movies/star_wars4.jpg" alt="Show 63">
                <img src="images/movies/star_wars6.jpg" alt="Show 64">
                <img src="images/movies/star_wars7.jpg" alt="Show 65">
                <img src="images/movies/the_conjuring1.jpg" alt="Show 66">
                <img src="images/movies/the_conjuring2.jpg" alt="Show 67">
                <img src="images/movies/the_fault_in_our_stars.png" alt="Show 68">
                <img src="images/movies/the_nun2.jfif" alt="Show 69">
                <img src="images/movies/thor.jpg" alt="Show 70">
                <img src="images/movies/titanic.jfif" alt="Show 71">
                <img src="images/movies/to_all_the_boys_ive_loved_before1.jpg" alt="Show 72">
                <img src="images/movies/to_all_the_boys_ive_loved_before2.jpg" alt="Show 73">
                <img src="images/movies/top_gun.jpg" alt="Show 74">
                <img src="images/movies/toy_story.jpg" alt="Show 75">
                <img src="images/movies/toy_story2.jpg" alt="Show 76">
                <img src="images/movies/uncharted.jfif" alt="Show 77">
                <img src="images/movies/world_war_z.jpg" alt="Show 78">
                <img src="images/movies/zodiac.jpg" alt="Show 79">
                <img src="images/series/alice_in_borderland.jfif" alt="Show 80">
                <img src="images/series/alienist.jpg" alt="Show 81">
                <img src="images/series/attack_on_titan.jfif" alt="Show 82">
                <img src="images/series/black_mirror.jpg" alt="Show 83">
                <img src="images/series/breaking_bad.jfif" alt="Show 84">
                <img src="images/series/bridgerton.jfif" alt="Show 85">
                <img src="images/series/dahmer.jpg" alt="Show 86">
                <img src="images/series/derry_girls.jpg" alt="Show 87">
                <img src="images/series/friends.jfif" alt="Show 88">
                <img src="images/series/haunting_of_hill_house.jpg" alt="Show 89">
                <img src="images/series/heartstopper.jpg" alt="Show 90">
                <img src="images/series/lucifer.jfif" alt="Show 91">
                <img src="images/series/midnight_club.jfif" alt="Show 92">
                <img src="images/series/one_piece.jfif" alt="Show 93">
                <img src="images/series/outer_banks.jfif" alt="Show 94">
                <img src="images/series/queens_gambit.jpg" alt="Show 95">
                <img src="images/series/riverdale.jpg" alt="Show 96">
                <img src="images/series/sabrina.jpg" alt="Show 97">
                <img src="images/series/squid_game.jpg" alt="Show 98">
                <img src="images/series/stranger_things.jfif" alt="Show 99">
                <img src="images/series/the_empress.jpg" alt="Show 100">
                <img src="images/series/the_society.jpg" alt="Show 101">
                <img src="images/series/the_walking_dead.jfif" alt="Show 102">
                <img src="images/series/wednesday.jpg" alt="Show 103">
                <img src="images/series/you.jpg" alt="Show 104">
            </div>
        </div>
    </div>
<!--********************************************************************************************************-->  

      <!--Navigation Bar-->

  <nav class="navbar navbar-expand-lg sticky-top bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="main_page.php">Home</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <!--a dropdown menu with the genres of movies-->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Movies
            </a>
            <ul class="dropdown-menu">  
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Action">Action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Animated">Animated</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Comedy">Comedy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Fantasy">Fantasy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Horror">Horror</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Romance">Romance</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Thriller">Thriller</a></li>
            </ul>
          </li> 

          <!--a dropdown menu with the genres of series-->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Series
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Action">Action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Animated">Animated</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Comedy">Comedy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Fantasy">Fantasy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Horror">Horror</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Romance">Romance</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Thriller">Thriller</a></li>
            </ul>
          </li> 

          <li class="nav-item">
            <a class="nav-link active" href="mylist_page.php">My list</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="recommendation_page.php">Recommendations</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="signup_page.php">Log out</a>
          </li>
        </ul>
  
        <!--the search bar-->
        <form class="d-flex" role="search" onsubmit="return search_page();">
          <input class="form-control me-2" type="search" id="searchInput" placeholder="Search" aria-label="Search" oninput="start_typing()">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>

      </div>
    </div>
  </nav>
<!--********************************************************************************************************-->  

            <!--Main body-->

  <!--the container of the movies and shows based on genres-->
  <div class="container mt-5" id="container">

      <!--container for the information and trailer of every movie and show-->
      <div class="modal" id="Modal">
          <div class="modal-dialog modal-lg modal-dialog-centered">
              <div class="modal-content">
                  <span class="close" onclick="close_modal()">&times;</span>
                  <iframe id="trailer" width="560" height="310" src="" frameborder="0" allowfullscreen></iframe>
                  <div class="modal-body" id="additionalInfo"></div>
              </div>
          </div>
      </div>
  </div>

  <script>
      $(document).ready(function()
      {
          //a list with the genres
          let genres = ['Action', 'Animated', 'Comedy', 'Fantasy', 'Horror', 'Romance', 'Thriller']; 

          //repeats the same process for all different genres
          genres.forEach(function(genre) 
          {
              //the container with the movies and shows based on the genre
              let container = ` <div class="category-container">
                                  <h2>${genre} Movies and Series you may like</h2>
                                  <div id="${genre}Carousel" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-indicators"></div>
                                      <div class="carousel-inner" id="${genre}CarouselInner"></div>
                                      <button class="carousel-control-prev" type="button" data-bs-target="#${genre}Carousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                      </button>
                                      <button class="carousel-control-next" type="button" data-bs-target="#${genre}Carousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                      </button>
                                    </div>
                                  </div>
              `;
              //appends it to the container
              $('#container').append(container).fadeIn(1000);
          });
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          $.ajax({
                      url: "getmovies.php",  //gets the data from the getmovies.php file
                      success: function(response)
                      {
                        let movies = JSON.parse(response);
                        
                        //a loop to repeat for each genre there exists
                        for(let genre in movies) 
                        {
                          //gets the element with id as the specific genre and concatinates it so that it can find the carousel of the specific genre
                          let carouselInner = $('#' + genre + 'CarouselInner');

                          //gets the element with id as the specific genre and concatinates it so that it can find the indicator of the carousel of the sepcific genre
                          let carouselIndicators = $('#' + genre + 'Carousel .carousel-indicators');

                          //a loop to display 3 movies at a time
                          for(let i = 0; i < movies[genre].length; i += 3) 
                          { 
                              //checks if it is the first movie in the set of 3
                              let first_movie;
                              if(i===0)
                              {
                                first_movie ='active';
                              }
                              else
                              {
                                first_movie='';
                              }
                              
                              //appends to the indicator a button that corresponds to the specific slide of the specific genre
                              //it also sets as index i/3 because it assumes that for every 3 movies, there is a slide
                              carouselIndicators.append('<button type="button" data-bs-target="#' + genre + 'Carousel" data-bs-slide-to="' + (i / 3) + '" class="' + first_movie + '"></button>');

                              //creates a div that adds in it the slide and the first movie of the 3 
                              let carouselItem = $('<div>').addClass('carousel-item ' + first_movie);

                              //a loop to append the movies in the carousel as long as it is less than the total amount of movies
                              //in the specific genre
                              for(let j = i; j < i + 3 && j < movies[genre].length; j++) 
                              {
                                  //retrieves the movie of the specific genre of the current index
                                  let movie = movies[genre][j];
                                 
                                  //appends the poster of the movie, the trailer, the description and the name
                                  carouselItem.append( `<div class="d-inline-block movie-poster mr-3" onclick="show_movie_details('${movie['name']}','${movie['trailer']}', '${movie['description']}', '${movie['info_link']}')">
                                                          <img src="${movie['image_link']}" class="d-block w-100" alt="${movie['name']}">
                                                        </div>`);
                              }
                              
                              //appends the carousel with the posters to the bigger carousel  
                              carouselInner.append(carouselItem);

                             
                            }
                          }
                        }
                  });
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //the effect for the dropdown when if slides down
            $('.dropdown').on('show.bs.dropdown', function(e)
            {
                $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
            });

            //the effect for the dropdown when if slides up
            $('.dropdown').on('hide.bs.dropdown', function(e)
            {
                $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
            });
      });
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      //a function to get the name, trailer, description and information link from the database
      function show_movie_details(movie_name, trailer_link, description, info_link) 
      {
          //saves the video link as an iframe in order to be able to display it
          let iframe = `<iframe id="trailer" width="300" height="315" src="${trailer_link}" frameborder="0" allowfullscreen></iframe>`;
          

          //shows the iframe for the trailer
          $('#trailer').replaceWith(iframe);


          //displays the name of the movie, the description, and information link as additional details
          $('#additionalInfo').html(`<h4>${movie_name}</h4>
                                    <p>${description}</p>
                                    <a href="${info_link}" class="btn btn-primary">More Info</a> 
                                    <button id="liked_button" class="btn btn-secondary">Add to list</button> 
                                    `);

           var username =  "<?php echo $_SESSION['username']; ?>"

          //directs to the liked movies
          $('#liked_button').on('click',function()
          {
            $.ajax({
              url: "getlikedmovie.php",
              data:{movie_name: movie_name, username: username},
              method: "POST",
              success: function(response)
              {
                const res = JSON.parse(response)
                if(res.error) {
                  alert(res.error.msg)
                  return
                }
                alert(res.msg)
              },
            
            })
          })

          $('#Modal').modal('show');    
      }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      //a function to close the container with the information of each movie seperately when the user presses the X button
      function close_modal() 
      {
          //hides the elements or replaces them with an empty string
          $('#Modal').modal('hide');
          $('#trailer').attr('src', '');
          $('#additionalInfo').html('');
      }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      //a variable for when the user is typing
      let typing = false;

      //a function to get the variable when the user is typing
      function start_typing() 
      {
          typing = true;
      }

      //a function to direct the user to the page with the information of the movies they have typed
      function search_page() 
      {
        if (typing) 
        {
            var get_name = $('#searchInput').val();
            $.ajax({
                      method: 'POST',
                      url: 'getsearch.php',
                      data: {name: get_name},
                      success: function(response) 
                              {
                                if (response.trim() != '') 
                                {
                                    window.location.href = 'search_page.php?name=' + get_name;
                                } 
                                else 
                                {
                                    alert('No movies found!');
                                }
                              }
                   });
            return false;
        }
        return true;
      }

  </script>
<!--********************************************************************************************************-->  

       <!-- Footer -->
       
  <footer class="text-center text-lg-start bg-body-tertiary text-muted">

    <section class="pt-4">
      <div class="container text-center text-md-start">
        <div class="row mt-3">

          <!--a div to display information about the purpose of the website-->
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-gem me-3"></i>About us</h6>
            <p>
              We are a small business that tries to supply the customers with movies and shows of all kinds and with very good quality.
              Sign in to get even more content and get updated regularly on new features!
            </p>
            <p>Editor's note: We are sorry for the lack of movies and shows. The website is constantly being updated.</p>
          </div>
  
          <!--a div to display information about the contents of the website-->
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4">Products</h6>
            <p><a href="#!" class="text-reset">Movies</a></p>
            <p><a href="#!" class="text-reset">Shows</a></p>
            <p><a href="#!" class="text-reset">List</a></p>
          </div>
  
          <!--a div to display contact information of the website-->
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
            <p><i class="fas fa-home me-3"></i> Institution, Place</p>
            <p>
              <i class="fas fa-envelope me-3"></i>
              <a href="mailto:youremail@gmail.com"> youremail@gmail.com</a>
            </p>
            
          </div>
        </div>
      </div>
    </section>

    <!-- Copyright -->
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
      © 2024 Copyright: Name Lastname
    </div>
  </footer>
 <!--********************************************************************************************************-->  
  
        <!--the background video--> 

  <video autoplay muted loop id="video">
      <source src="images/background_video.mp4" type="video/mp4">
  </video>
  <!--********************************************************************************************************-->   


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  
</body>
</html>
