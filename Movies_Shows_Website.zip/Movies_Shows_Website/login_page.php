<?php
    //starts the session
    session_start();

    include "dbconfig.php";
    
    //initialise the variables as empty 
    $username = $password = "";
    $username_err = $password_err = $login_err = "";
    
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        //gets the username and the password
        $username = $_POST["username"];
        $password = $_POST["password"];

        //connects to database
        $db_conn = connect_to_database();

        $sql = "SELECT id, username, password FROM users_table WHERE username = ?";
        
        if($statement = mysqli_prepare($db_conn, $sql))
        {
            mysqli_stmt_bind_param($statement, "s", $param_username);
            $param_username = $username;
            
            if(mysqli_stmt_execute($statement))
            {
                //stores result
                mysqli_stmt_store_result($statement);
                
                //checks if username exists
                if(mysqli_stmt_num_rows($statement) == 1)
                {                    
                    //binds result variables
                    mysqli_stmt_bind_result($statement, $id, $username, $db_password);
                    if(mysqli_stmt_fetch($statement))
                    {
                        //if the password given is the same as the one saved in the database, meaning it is correct
                        if($password == $db_password)
                        { 
                            //starts the session
                            session_start();
                            
                            //stores data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            //redirects user to the main page
                            header("location: main_page.php");
                        } 

                        //if the password is incorrect
                        else
                        {
                            $login_err = "Invalid username or password.";
                            echo "<script>alert('Invalid username or password.'); window.location='login_page.php';</script>";
                        }
                    }
                } 
                else
                {
                    $login_err = "Invalid username or password.";
                    echo "<script>alert('Invalid username or password.'); window.location='login_page.php';</script>";
                }
            } 
            else
            {
                echo "Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($statement);
        }
    }
?>
<!--********************************************************************************************************-->  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="login.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
    <title>MovieMania</title>
</head>
<body>

    <!--The form for the user to signup-->

    <div class="container">
        <p><h1>Log in to your account!</h1></p>
        <form action="login_page.php" method="post"> 
            <label for="username">Username</label>
            <div class="form-group">
                <div class="input-group">
                    <a class="icon-link icon-link-hover" style="--bs-icon-link-transform: translate3d(0, -.125rem, 0);" href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="font-size: 28px;">
                            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
                            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
                        </svg>
                    </a>
                    <input type="text" name="username" class="icon-input" required>
                </div>
            </div>

            <label for="password">Password</label>
            <div class="form-group">
                <div class="input-group">
                    <a class="icon-link icon-link-hover" style="--bs-icon-link-transform: translate3d(0, -.125rem, 0);" href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-lock2" viewBox="0 0 16 16" style="font-size: 28px;">
                            <path d="M8 5a1 1 0 0 1 1 1v1H7V6a1 1 0 0 1 1-1m2 2.076V6a2 2 0 1 0-4 0v1.076c-.54.166-1 .597-1 1.224v2.4c0 .816.781 1.3 1.5 1.3h3c.719 0 1.5-.484 1.5-1.3V8.3c0-.627-.46-1.058-1-1.224"/>
                            <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
                        </svg>
                    </a>
                    <input type="password" name="password" class="icon-input" required>
                </div>
            </div>            

            <div class="form-group">
                <input type="submit" value="Log in">
            </div>
        </form>
    </div>
    <p style="text-align:center;">Don't have an account? <a href="signup_page.php">Sign up here</a>.</p>
    <!--********************************************************************************************************-->  
    <footer>
        <p>Having problems signing up or logging in? Contact us here: <a href="mailto:youremail@gmail.com"> youremail@gmail.com</a></p>
    </footer>
    <!--********************************************************************************************************-->  
    <script>
        $(document).ready(function()
        {
            //the effect for the dropdown when if slides down
            $('.dropdown').on('show.bs.dropdown', function(e)
                {
                    $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
                });

                //the effect for the dropdown when if slides up
                $('.dropdown').on('hide.bs.dropdown', function(e)
                {
                    $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
                });
            });
        </script>
    <!--********************************************************************************************************-->  

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>