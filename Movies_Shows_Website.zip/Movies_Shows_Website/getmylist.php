<?php
    include "dbconfig.php";

    //connects to the database
    $db_conn=connect_to_database();

    //gets the username
    $username = $_GET['username'];

    //gets the movies that the user has liked
    $sql = "SELECT * FROM movies_and_series_table a join user_movie_liked b on a.name=b.movie_name where b.username='$username'";

    $query = mysqli_query($db_conn, $sql);
    $data = [];

    //stores the liked movies in an array 
    while($row = mysqli_fetch_assoc($query))
    {
        $data[] = $row;
    }

    echo json_encode($data);
?>