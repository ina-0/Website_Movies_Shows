<?php
    include "dbconfig.php";
    create_database();
    session_start();
    //initialise the variables as empty 
    $username = $password = $hashed_password = $age = "";
    $username_err = "";

    //gets the username, password and age from the form
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        //gets the username, the password and the age
        $username = $_POST["username"];
        $password = $_POST["password"];
        $age = $_POST["age"];

        //connects to database
        $db_conn = connect_to_database();

        //checks if the username already exists
        $check_query = "SELECT * FROM users_table WHERE username = ?";
        $check_statement = mysqli_prepare($db_conn, $check_query);
        mysqli_stmt_bind_param($check_statement, "s", $username);
        mysqli_stmt_execute($check_statement);
        mysqli_stmt_store_result($check_statement);

        //if the username already exists
        if(mysqli_stmt_num_rows($check_statement) > 0) 
        {
            $username_err = "Username already taken!";
            mysqli_stmt_close($check_statement);
            mysqli_close($db_conn);
            echo "<script>alert('Username already taken, try again!'); window.location='signup_page.php';</script>";
        }
        else 
        {
            //inserts the information that the user has entered into the users_table if the username doesn't exist
            $query = "INSERT INTO users_table (username, password, age) VALUES (?, ?, ?)"; 

            $statement = mysqli_prepare($db_conn, $query);

            mysqli_stmt_bind_param($statement, "ssi", $username, $password, $age);

            if (mysqli_stmt_execute($statement)) 
            {
                $_SESSION['username']=$username;
                mysqli_stmt_close($statement);
                mysqli_close($db_conn);
                echo "<script>alert('Signup successful!'); window.location='main_page.php';</script>";
                exit;
            } 
            else 
            {
                echo "<script>alert('Signup failed! Please try again.');</script>";
            }
        }
    }
?>
<!--********************************************************************************************************-->  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="signup.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
    <title>MovieMania</title>
</head>
<body>

    <!--The form for the user to signup-->

    <div class="container">
        <p><h1>Create a new account!</h1></p>
        <form action="signup_page.php" method="post"> 
        <label for="username">Username</label>
        <div class="form-group">
            <div class="input-group">
                <a class="icon-link icon-link-hover" style="--bs-icon-link-transform: translate3d(0, -.125rem, 0);" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="font-size: 28px;">
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
                        <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
                    </svg>
                </a>
                <input type="text" name="username" class="icon-input" required v-model="username">
            </div>
        </div>

        <label for="password">Password</label>
        <div class="form-group">
            <div class="input-group">
                <a class="icon-link icon-link-hover" style="--bs-icon-link-transform: translate3d(0, -.125rem, 0);" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-lock2" viewBox="0 0 16 16" style="font-size: 28px;">
                        <path d="M8 5a1 1 0 0 1 1 1v1H7V6a1 1 0 0 1 1-1m2 2.076V6a2 2 0 1 0-4 0v1.076c-.54.166-1 .597-1 1.224v2.4c0 .816.781 1.3 1.5 1.3h3c.719 0 1.5-.484 1.5-1.3V8.3c0-.627-.46-1.058-1-1.224"/>
                        <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
                    </svg>
                </a>
                <input type="password" name="password" class="icon-input" required>
            </div>
        </div>

            <label for="age">Age</label>
            <div class="form-group">
            <div class="input-group">
                <a class="icon-link icon-link-hover" style="--bs-icon-link-transform: translate3d(0, -.125rem, 0);" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hourglass-split" viewBox="0 0 16 16" style="font-size: 28px;">
                        <path d="M2.5 15a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1zm2-13v1c0 .537.12 1.045.337 1.5h6.326c.216-.455.337-.963.337-1.5V2zm3 6.35c0 .701-.478 1.236-1.011 1.492A3.5 3.5 0 0 0 4.5 13s.866-1.299 3-1.48zm1 0v3.17c2.134.181 3 1.48 3 1.48a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351z"/>
                    </svg>
                </a>
                <input type="number" name="age" class="icon-input" required>
            </div>
        </div>

            <div class="form-group">
                <input type="submit" value="Sign up">
            </div>
        </form>
    </div>
    <p style="text-align:center;">Already have an account? <a href="login_page.php">Login here</a>.</p>
    <!--********************************************************************************************************-->  
    <footer>
        <p>Having problems signing up or logging in? Contact us here: <a href="mailto:youremail@gmail.com"> youremail@gmail.com</a></p>
    </footer>
    <script>
        $(document).ready(function()
        {
            //the effect for the dropdown when if slides down
            $('.dropdown').on('show.bs.dropdown', function(e)
                {
                    $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
                });

                //the effect for the dropdown when if slides up
                $('.dropdown').on('hide.bs.dropdown', function(e)
                {
                    $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
                });
            });
        </script>
    <!--********************************************************************************************************-->  

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
