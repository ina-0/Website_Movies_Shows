<?php

include "dbconfig.php";

//calls the function and stores it as a variable
$db_conn=connect_to_database();

//a list with the names of the genres
$genres = ['Action', 'Animated', 'Comedy', 'Fantasy','Horror','Romance','Thriller'];

//an empty list to store the movies and shows that belong to a specific genre
$movies_series = [];

//a loop that gets the movies and shows for each genre
foreach($genres as $genre)
{
    $sql = "SELECT * FROM movies_and_series_table WHERE genre = '$genre'";
    $result = mysqli_query($db_conn,$sql);
    while($row=mysqli_fetch_assoc($result))
    {
        $movies_series[$genre][]=$row;
    }
}
echo json_encode($movies_series);

?>
