<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="genrepage.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
    <title>MovieMania</title>
</head>
<body>

<!--********************************************************************************************************-->  

      <!--Navigation Bar-->

  <nav class="navbar navbar-expand-lg sticky-top bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="main_page.php">Home</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <!--a dropdown menu with the genres of movies-->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Movies
            </a>
            <ul class="dropdown-menu">  
            <li><a class="dropdown-item" href="movie_genre_page.php?genre=Action">Action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Animated">Animated</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Comedy">Comedy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Fantasy">Fantasy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Horror">Horror</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Romance">Romance</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="movie_genre_page.php?genre=Thriller">Thriller</a></li>
            </ul>
          </li> 

          <!--a dropdown menu with the genres of series-->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Series
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Action">Action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Animated">Animated</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Comedy">Comedy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Fantasy">Fantasy</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Horror">Horror</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Romance">Romance</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="series_genre_page.php?genre=Thriller">Thriller</a></li>
            </ul>
          </li> 

          <li class="nav-item">
            <a class="nav-link active" href="mylist_page.php">My list</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="recommendation_page.php">Recommendations</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="signup_page.php">Log out</a>
          </li>
        </ul>
  
        <!--the search bar-->
        <form class="d-flex" role="search" onsubmit="return search_page();">
          <input class="form-control me-2" type="search" id="searchInput" placeholder="Search" aria-label="Search" oninput="start_typing()">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>

      </div>
    </div>
  </nav>
<!--********************************************************************************************************-->    

        <!--the php needed to get the movies based on the genre-->
        <?php
            include "dbconfig.php";
            $db_conn=connect_to_database();
            if(isset($_GET['genre'])) 
            {
                $searchGenre = $_GET['genre'];
                $sql = "SELECT * FROM movies_and_series_table WHERE ms_type='Movie' AND genre='$searchGenre'";
                $query = mysqli_query($db_conn, $sql);
        ?>

            <!--the container of the movies of the specific genre-->
            <div class="container mt-4">
                <p><h2>These are the <?php echo $searchGenre; ?> movies.</h2></p>
                <div class="row" id="showdata">

                <?php  
                    //as long as there are movies that correspond to the movie that the user searched
                    if (mysqli_num_rows($query) > 0) 
                    {
                        //displays the poster, the name, the description and 2 buttons with additional information and youtube link
                        while($row = mysqli_fetch_assoc($query))
                        {
                            echo '<div class="card ">';
                            echo '<img src="'.$row['image_link'].'" class="card-img-top" alt="Movie Poster">';
                            echo '<div class="card-body">';
                            echo '<h5 class="card-title">'.$row['name'].'</h5>';
                            echo '<p class="card-text">'.$row['description'].'</p>';
                            echo '<div class="btn-group">';
                            echo '<a href="'.$row['info_link'].'" class="btn btn-primary" target="_blank">More info</a>';
                            echo '<a href="'.$row['trailer'].'" class="btn btn-danger" target="_blank">Watch trailer</a>';
                            echo '</div>';  
                            echo '</div></div>'; 
                        }
                    }
                    //in case there isn't any movie with the same name that the user typed
                    else 
                    {
                        echo '<div class="col">';
                        echo '<p>No movies found matching your search.</p>';
                        echo '</div>';
                    }
                ?>
                </div>
            </div>

        <?php
            }
        ?>
  <!--********************************************************************************************************-->  
    <script>
      $(document).ready(function()
      {
        //the effect for the dropdown when if slides down
        $('.dropdown').on('show.bs.dropdown', function(e)
            {
                $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
            });

            //the effect for the dropdown when if slides up
            $('.dropdown').on('hide.bs.dropdown', function(e)
            {
                $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
            });
        });
      /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //a variable for when the user is typing
        let typing = false;

        //a function to get the variable when the user is typing
        function start_typing() 
        {
            typing = true;
        }

        //a function to direct the user to the page with the information of the movies they have typed
        function search_page() 
        {
            if (typing) 
            {
                var get_name = $('#searchInput').val();
                $.ajax({
                            method: 'POST',
                            url: 'getsearch.php',
                            data: {name: get_name},
                            success: function(response) 
                                    {
                                    if (response.trim() != '') 
                                    {
                                        window.location.href = 'search_page.php?name=' + get_name;
                                    } 
                                    else 
                                    {
                                        alert('No movies found!');
                                    }
                                    }
                        });
                return false;
            }
            return true;
        }
    </script>
<!--********************************************************************************************************-->  

       <!-- Footer -->
       
       <footer class="text-center text-lg-start bg-body-tertiary text-muted">

        <section class="pt-4">
        <div class="container text-center text-md-start">
            <div class="row mt-3">

            <!--a div to display information about the purpose of the website-->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-gem me-3"></i>About us</h6>
                <p>
                    We are a small business that tries to supply the customers with movies and shows of all kinds and with very good quality.
                    Sign in to get even more content and get updated regularly on new features!
                </p>
                <p>Editor's note: We are sorry for the lack of movies and shows. The website is constantly being updated.</p>
            </div>

            <!--a div to display information about the contents of the website-->
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold mb-4">Products</h6>
                <p><a href="#!" class="text-reset">Movies</a></p>
                <p><a href="#!" class="text-reset">Shows</a></p>
                <p><a href="#!" class="text-reset">List</a></p>
            </div>

            <!--a div to display contact information of the website-->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                <p><i class="fas fa-home me-3"></i> Institution, Place</p>
                <p>
                    <i class="fas fa-envelope me-3"></i>
                    <a href="mailto:youremail@gmail.com"> youremail@gmail.com</a>
                </p>

            </div>
            </div>
        </div>
        </section>

        <!-- Copyright -->
        <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
            © 2024 Copyright: Name Lastname
        </div>
        </footer>
<!--********************************************************************************************************-->  

    <!--the background video--> 

    <video autoplay muted loop id="video">
    <source src="images/background_video.mp4" type="video/mp4">
    </video>
<!--********************************************************************************************************-->   


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>