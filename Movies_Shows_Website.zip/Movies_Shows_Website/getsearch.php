<?php
    include "dbconfig.php";

    $name = $_POST['name'];

    //selects the names of the movies without being case-sensitive
    $sql = "SELECT name FROM movies_and_series_table WHERE name LIKE '%$name%'";
    $query = mysqli_query($db_conn, $sql);
    $data = '';
    while($row = mysqli_fetch_assoc($query))
    {
        $data .= $row['name'];
    }
    echo $data;
?>