<?php
    include "dbconfig.php";

    //connects to the database
    $db_conn=connect_to_database();

    //gets the username
    $username = $_GET['username'];

    //get the movies that other users have liked, in case they share at least one common liked movie
    $sql = "SELECT *
            FROM movies_and_series_table a
            JOIN user_movie_liked b on b.movie_name = a.name
            WHERE b.username != '$username'
            AND a.name NOT IN
            (SELECT DISTINCT a.movie_name FROM user_movie_liked a join user_movie_liked b ON a.movie_name = b.movie_name WHERE a.username = '$username');
            ";

    $query = mysqli_query($db_conn, $sql);
    $data = [];

    while($row = mysqli_fetch_assoc($query))
    {
        $data[] = $row;
    }

    echo json_encode($data);
?>