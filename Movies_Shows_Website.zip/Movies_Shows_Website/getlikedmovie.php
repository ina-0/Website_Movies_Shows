<?php
include 'dbconfig.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    //connects to the database
    $db_conn = connect_to_database();

    //gets the username and the name of the movie
    $username = $_POST['username'] ?? '';
    $movie_name = $_POST['movie_name'] ?? '';

    //if the username and the name of the movie exist
    if (!empty($username) && !empty($movie_name)) 
    {   
        //selects all liked movies from the specific user
        $sql_err = "SELECT * FROM user_movie_liked WHERE username = '$username' AND movie_name = '$movie_name';";
       
        if ($result=mysqli_query($db_conn,$sql_err)) 
        {
            $resultsCount = mysqli_fetch_assoc($result);

            //if the movie has already been added to the list
            if($resultsCount > 0) 
            {
                echo json_encode(array(
                    'error' => array(
                        'msg' => 'Movie already exists!',
                        'code' => 400
                    ),
                ));
                return;
            }
        }
       
        //insert into user_liked_movies table
        $msg = '';
        $sql = "INSERT INTO user_movie_liked (username, movie_name) VALUES (?, ?)";
        $stmt = $db_conn->prepare($sql);
       
            //insert into user_liked_movies table
            $stmt->bind_param('ss', $username, $movie_name);
            
            if ($stmt->execute()) 
            {
                $msg = 'Movie added to list successfully!';
            } else 
            {
                $msg = 'Failed to add movie to list.';
            }
            echo json_encode(array(
                'msg' => $msg
            ));

        $stmt->close();
    } 
    else 
    {
        echo 'Invalid request.';
    }

}
?>
